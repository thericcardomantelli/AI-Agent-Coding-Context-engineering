# AGENTS.md

# Scopo del progetto
Sintetizzare un libro in formato PDF capitolo per capitolo.

# Contesto
Il PDF contiente uno o più capitoli di un libro, ma non deve ricostruire ogni passaggio o argomentazione.
Deve concentrarsi sulle idee necessarie per comprendere la tesi generale del libro e il contenuto essenziale di ciascun capitolo.

# Input 
- PDF 
- Eventuali indicazioni da parte dell'utente

# Struttura del progetto
/PDF Contiene il documento in PDF da sintetizzare
/Riassunti E' la cartella dove salvare i riassunti generati

# Workflow 

1. Leggi l’indice e identifica i capitoli del libro.
2. Leggi il testo una sola volta, procedendo in ordine.
3. Per ogni capitolo individua la tesi principale e un massimo di cinque concetti importanti.
4. Scrivi immediatamente il relativo riassunto nel documento finale.
5. Al termine controlla soltanto che tutti i capitoli siano presenti e che non ci siano ripetizioni evidenti.

Non creare un task separato per ogni capitolo.
Non produrre file temporanei, appunti intermedi o analisi separate.
Non mostrare aggiornamenti continui durante il lavoro: genera direttamente il documento finale.

# Output
Per ogni capito restituisci:
###Titolo del capitolo
Riassunto di circa 200–350 parole.
#### Concetti chiave
massimo 5 concetti;
ogni concetto deve essere spiegato in una frase breve.

#### Parole chiave
Da 5 a 10 parole chiave separate da virgole.

Al termine aggiungi:
####Sintesi generale del libro

Una sintesi complessiva di massimo 500 parole che spieghi:

- la tesi centrale del libro;
- il collegamento tra i capitoli;
- le conclusioni principali dell’autore.

# Regole
- Non inventare informazioni.
- Non aggiungere interpretazioni personali.
- Non riassumere frase per frase.
- Non ripetere gli stessi concetti in capitoli diversi.
- Non riportare esempi secondari, salvo quando indispensabili.
- Non modificare il significato del testo.
- Evita ripetizioni.
- Mantieni un stile chiaro e scorrevole
- Riporta nomi, date, formule e definizioni soltanto quando sono essenziali alla comprensione.
- Non suddividere ulteriormente i capitoli, salvo quando superano chiaramente le 40 pagine.

# Stile
Scrivi in italiano chiaro, scorrevole e accessibile.
Usa paragrafi brevi e frasi dirette.
Evita formule come “l’autore afferma che” quando non sono necessarie.
Mantieni un tono neutro e adatto allo studio.

# Strumenti tecnologici
Puoi usare una libreria python3 per estrarre il testo dal PDF

