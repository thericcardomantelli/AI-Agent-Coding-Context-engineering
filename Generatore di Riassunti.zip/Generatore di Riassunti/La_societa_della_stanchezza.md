# La società della stanchezza — Byung-Chul Han

Riassunto capitolo per capitolo del saggio filosofico di Byung-Chul Han (edizione ampliata con l'appendice *La società del burnout* e *Tempo solenne*).

---

### Premessa alla sesta edizione tedesca: Il Prometeo stanco

Il mito di Prometeo diventa allegoria dell'apparato psichico del soggetto contemporaneo: incatenato non da un dio esterno ma da se stesso, si dilania continuamente in un rapporto di autosfruttamento. L'aquila che gli divora il fegato è il suo alter ego interiore, e il dolore che ne deriva prende oggi la forma di una stanchezza cronica senza fine. Prometeo è così l'archetipo dell'uomo che, credendosi libero, muove guerra contro di sé. Contro questa stanchezza distruttiva Han evoca però un'altra stanchezza, ispirata a Kafka: una "stanchezza che cura", capace di richiudere le ferite invece di aprirle. Non nasce dal riarmo del sé, ma dal suo pacifico disarmo. Attorno a questa doppia figura — stanchezza dell'autoviolenza e stanchezza risanatrice — ruota l'intero saggio.

#### Concetti chiave
- **Prometeo come soggetto di prestazione**: la libertà proclamata è in realtà una catena interiorizzata.
- **Autosfruttamento**: il soggetto è al tempo stesso vittima e carnefice di se stesso.
- **Stanchezza come sintomo**: il dolore del fegato è la fatica strutturale dell'io.
- **Guerra intestina**: la violenza non arriva dall'esterno ma dal rapporto conflittuale con l'alter ego.
- **Stanchezza che cura**: un disarmo dell'io capace di richiudere le ferite, opposto alla stanchezza da esaurimento.

#### Parole chiave
Prometeo, autosfruttamento, stanchezza, prestazione, alter ego, disarmo, cura, ferita

---

### La violenza neuronale

Ogni epoca ha le proprie malattie. Il Novecento è stato batterico e virale, dominato dallo schema immunologico dell'attacco all'Estraneo. Il XXI secolo, invece, è caratterizzato da patologie neuronali: depressione, ADHD, disturbo borderline, burnout. Non nascono da un'infezione esterna, ma da un eccesso di positività, di stimoli, di comunicazione, di prestazione. Han contesta l'immunologia sociale di Esposito e Baudrillard: nell'epoca globalizzata l'alterità è stata sostituita dalla differenza, che è già consumo e non provoca reazione immunitaria. L'estraneo diventa esotico, il turista è il suo consumatore. In un sistema saturo di Eguale, la violenza non è più privativa ma saturativa, non esclude ma satura. Non c'è nemico interno né esterno: la violenza è immanente al sistema stesso. Le patologie neuronali sono infarti psichici prodotti da una sovrapproduzione dell'Eguale, e sfuggono a ogni difesa immunitaria perché non hanno un fuori a cui opporsi. È una violenza sistemica, senza volto, che si manifesta come esaurimento, saturazione, soffocamento. L'iperattività non è una categoria del contrasto immunologico, ma la forma stereotipata di una positività divenuta patologica.

#### Concetti chiave
- **Fine del paradigma immunologico**: l'alterità si dissolve nella differenza addomesticata.
- **Eccesso di positività**: la salute e la malattia dipendono ora dalla saturazione, non dalla negazione.
- **Violenza dell'Eguale**: nasce dall'omologazione, non dallo scontro con l'Altro.
- **Malattie neuronali del XXI secolo**: depressione, ADHD, burnout come infarti di un sistema iper-positivo.
- **Violenza immanente**: il sistema non ha nemico esterno, ma si logora dall'interno.

#### Parole chiave
neuronale, immunologia, positività, Eguale, alterità, burnout, globalizzazione, saturazione

---

### Oltre la società disciplinare

La società analizzata da Foucault — fatta di prigioni, manicomi, caserme, fabbriche — è finita. Al suo posto è emersa la società della prestazione: fitness center, uffici, banche, aeroporti, centri commerciali. Il cittadino non è più "soggetto d'obbedienza" ma "soggetto di prestazione", imprenditore di se stesso. Il verbo modale è passato dal "non-potere" del divieto al "poter-fare" illimitato dello *Yes we can*. Non si tratta però di una rottura, ma di una continuità: la positività del poter-fare è più efficiente della negatività del dovere per massimizzare la produzione. Il soggetto di prestazione ha interiorizzato la disciplina e la spinge oltre. Han critica Ehrenberg: la depressione non nasce dall'imperativo di "essere se stessi", ma dalla pressione della prestazione e dalla violenza sistemica. Il depresso non è il "superuomo" sovrano annunciato da Nietzsche, ma "l'ultimo uomo" che lavora. Fa guerra a se stesso, è al contempo vittima e carnefice. La libertà, senza istanza esterna di dominio, coincide con una costrizione autoreferenziale. Da qui la libertà paradossale della società della prestazione: più il soggetto crede di essere libero, più si sfrutta senza freni. Le malattie psichiche di oggi sono l'esito di questa libertà rovesciata in violenza.

#### Concetti chiave
- **Dalla disciplina alla prestazione**: dal soggetto d'obbedienza al soggetto imprenditore di sé.
- **Poter-fare al posto del dovere**: la positività produce di più della negatività del divieto.
- **Continuità, non rottura**: la disciplina resta interiorizzata sotto forma di autoimperativo.
- **Depressione come infarto psichico**: non fallimento dell'essere se stessi ma della prestazione infinita.
- **Libertà costrittiva**: la coincidenza di libertà e costrizione è il fondamento dell'autosfruttamento.

#### Parole chiave
prestazione, disciplina, poter-fare, autosfruttamento, depressione, Foucault, imprenditore di sé, libertà paradossale

---

### La noia profonda

L'eccesso di positività si traduce in eccesso di stimoli, informazioni, impulsi. L'attenzione diventa frammentata e superficiale. Il multitasking, celebrato come progresso, è in realtà un regresso: è la tecnica attentiva dell'animale selvatico che deve controllare sfondo e predatori mentre mangia, non ammette immersione contemplativa. L'iperattenzione moderna imita questa vigilanza dispersa, e tollera pochissimo la noia. Ma la noia profonda, dice Han citando Walter Benjamin, è "l'uccello incantato che cova l'uovo dell'esperienza": è nel riposo che nasce ciò che è veramente nuovo. La pura frenesia riproduce l'esistente e non genera nulla. Dal camminare accelerato si può accedere alla danza solo se si sopporta la noia; la danza è un lusso che si sottrae al principio di prestazione. La vita contemplativa si radica nello stupore per l'essere-così delle cose, non nel dubbio moderno. Anche ciò che è impercettibile o lento richiede attenzione profonda: Cézanne diceva di "vedere l'odore" delle cose, e Merleau-Ponty descrive la sua visione come una de-interiorizzazione capace di sintesi. Anche Nietzsche invocava un rafforzamento dell'elemento contemplativo per non precipitare in una nuova barbarie fatta di iperattivi senza riposo. La cultura è impossibile senza tempi vuoti in cui la mente si sospende.

#### Concetti chiave
- **Iperattenzione come regresso**: il multitasking replica la vigilanza dispersa dell'animale in habitat ostile.
- **Noia profonda come culla della creatività**: senza riposo spirituale nulla di nuovo può nascere.
- **Danza vs. accelerazione**: la danza rappresenta la forma di movimento sottratta al principio di prestazione.
- **Vita contemplativa e stupore**: la contemplazione si fonda sullo stupore, non sull'attivismo.
- **Attenzione profonda e sintesi**: solo un occhio lento coglie le forme, le durate e ciò che sfugge all'iperattività.

#### Parole chiave
noia, contemplazione, multitasking, attenzione, iperattenzione, Benjamin, Cézanne, stupore, riposo

---

### Vita activa

Hannah Arendt in *Vita activa* cerca di riabilitare la vita attiva contro il primato tradizionale della vita contemplativa, orientando l'agire alla nascita e al nuovo inizio. Han obietta che questa enfasi eroica dell'agire è in realtà consegnata all'iperattivismo, e non regge alla prova della società attuale. L'*animal laborans* tardo-moderno non annulla la propria individualità nell'anonimo processo vitale della specie, come pensava Arendt: è invece straboccante di ego, iperattivo e ipernevrotico. Ciò che rende ogni attività umana simile a mero lavoro è la perdita di fede, di narrazione e di durata: nulla resta, nulla è promesso, e la nuda vita — sopravvivenza — è divenuta l'unico orizzonte. Nietzsche l'aveva previsto: dopo la morte di Dio, la salute diventa la nuova divinità. La vita del soggetto contemporaneo è più nuda di quella dell'*homo sacer* di Agamben: siamo tutti *homines sacri*, ma non uccidibili, bensì "morti viventi", conservati a ogni costo. Alla nuda vita si reagisce con l'isteria del lavoro e della prestazione. Perfino il signore è ormai servo, ciascuno porta con sé la propria cella. Arendt, verso la fine del libro, evoca involontariamente la vita contemplativa, ma non si accorge che la perdita della contemplazione è corresponsabile della nevrosi della società dell'azione.

#### Concetti chiave
- **Critica di Arendt**: la sua *animal laborans* non descrive l'ipernevrotico di oggi, ricco di ego.
- **Nuda vita e sopravvivenza**: senza narrazione, la vita si riduce a mera funzione biologica.
- **Salute come nuova divinità**: dopo la morte di Dio, il culto della salute assolutizza la sopravvivenza.
- **Homo sacer inuccidibile**: siamo morti viventi da preservare, non da eliminare.
- **Iperattività come reazione al vuoto d'essere**: la frenesia compensa la fugacità del reale.

#### Parole chiave
Arendt, animal laborans, nuda vita, sopravvivenza, homo sacer, salute, contemplazione, iperattivismo

---

### La pedagogia del vedere

Nietzsche, nel *Crepuscolo degli idoli*, propone tre apprendimenti: vedere, pensare, parlare-scrivere. Imparare a vedere significa educare l'occhio alla calma, alla pazienza, al lasciare-venire-a-sé; è la prima istruzione alla spiritualità. Non è passività, ma resistenza attiva all'impulso, capacità di dire "no" agli stimoli che premono. La vita contemplativa non è un "sì" indiscriminato: è una sovranità che oppone gli "istinti che concludono" alla dispersione. Da qui la dialettica: quando l'attività si intensifica in iperazione, si rovescia in iperpassività, perché segue senza freni ogni impulso. Han distingue potenza positiva (poter-fare) e potenza negativa (poter-non-fare), quest'ultima ben diversa dalla mera impotenza. Solo la potenza negativa permette di sospendere, filtrare, riflettere; senza di essa la percezione è esposta senza difese all'invasione degli stimoli, il pensiero si dissolve nel calcolo. La meditazione zen è pura attività della potenza negativa, non passività. Analogamente scompaiono la collera — che interrompe uno stato e ne inaugura un altro — sostituita da irritazione e nervosismo, incapaci di generare mutamento. La generale positivizzazione livella lo stato di eccezione nel normale e trasforma l'uomo e la società in una "macchina di prestazione autistica", simile all'*idiot savant* privo di alterità.

#### Concetti chiave
- **Pedagogia del vedere**: l'occhio va educato alla lentezza e alla resistenza all'impulso.
- **Potenza negativa**: il potere di non fare, distinto dall'impotenza, è condizione della spiritualità.
- **Iperattività = iperpassività**: chi segue ogni stimolo perde la propria sovranità attiva.
- **Scomparsa della collera**: la crescente positività dissolve l'energia interruttiva della rabbia.
- **Pensiero vs. calcolo**: senza negatività il pensiero regredisce a mera funzione autistica di calcolo.

#### Parole chiave
Nietzsche, vedere, potenza negativa, contemplazione, iperattività, collera, zen, sovranità

---

### Il caso Bartleby

Il celebre racconto di Melville non va letto in chiave onto-teologica (come propone Agamben), ma patologica. Descrive una società disciplinare dominata da muri — la "storia di Wall Street" è punteggiata da *dead walls*, tombe, prigioni. Gli impiegati soffrono nevrosi, iperattività, disturbi psicosomatici; Bartleby, con la sua formula "preferirei di no", non è portatore di una potenza pura ma di una nevrastenia demotivata. Egli è ancora un soggetto d'obbedienza, non un soggetto di prestazione: non conosce l'iper-logoramento dell'io tipico della depressione tardo-moderna, non porta il peso dell'imperativo di "far cominciare l'io da sé". Il copiare monotono che gli è affidato non ammette iniziativa; non è dunque la libertà eccessiva a fiaccarlo, ma la macchina disciplinare che lo pietrifica. Han critica Agamben, che fa di Bartleby un angelo dell'annuncio, un puro "essere senza predicato" incarnazione della *potentia absoluta*: gli occhi stanchi e offuscati, il rifiuto di ogni incarico e il lavoro all'ufficio delle lettere morte parlano una lingua ben diversa, quella dell'esaurimento e della negatività per la morte. Il racconto non offre alcuna redenzione messianica: la chiazza d'erba nel cortile della prigione rafforza soltanto la negatività del regno dei morti. La "storia di Wall Street" è una storia di esaurimento (*Erschöpfung*), non di de-creazione (*Entschöpfung*). Non ha la fisionomia del burnout, ma quella della malinconia disciplinare.

#### Concetti chiave
- **Lettura patologica di Bartleby**: la formula "preferirei di no" è nevrastenia, non potenza pura.
- **Bartleby come soggetto d'obbedienza**: appartiene alla società disciplinare, non a quella della prestazione.
- **Critica ad Agamben**: nessuna *potentia absoluta*, ma esaurimento e negatività per la morte.
- **Il muro come simbolo disciplinare**: l'architettura del racconto è fatta di muri, tombe, prigioni.
- **Esaurimento vs. de-creazione**: la vera cifra del racconto è la stanchezza mortale, non l'annuncio messianico.

#### Parole chiave
Bartleby, Melville, Agamben, disciplina, muri, nevrastenia, esaurimento, obbedienza

---

### La società della stanchezza

La società della prestazione si evolve in società del doping: la separazione tra "doping cerebrale" e "accrescimento neuronale" è già una vittoria della logica per cui l'essere umano è una macchina di performance da massimizzare. Il rovescio di questa iperprestazione è la stanchezza da esaurimento, un infarto dell'anima. Han distingue però due stanchezze, riprendendo il *Saggio sulla stanchezza* di Peter Handke. La prima è la "stanchezza che divide": muta, afasica, isolante, riempie il campo visivo con il solo io e brucia la parola, la vista, la comunanza. È la stanchezza dell'iperprestazione, dello sfruttamento assoluto della potenza positiva. La seconda è una "stanchezza fondamentale" o "stanchezza del noi": non incapacità, ma capacità peculiare. Allenta le parentesi dell'io, apre un "tra" cortese in cui non c'è più predominio, e restituisce mondo, dualità, contatto. È stanchezza della potenza negativa, del non-fare: ispira, disarma, rende ammirevoli le cose, e riporta lo stupore. La stanchezza profonda è affine allo Shabbat, giorno del non-fare, dell'utilizzo dell'inutilizzabile, tempo di gioco e di pace, non di semplice riposo. Handke immagina una "accolita pentecostale" di stanchi: una società futura in cui il ritmo lento della stanchezza fonda una comunità senza vincoli funzionali. Questa società ipotetica potrebbe chiamarsi, letteralmente, società della stanchezza.

#### Concetti chiave
- **Doping e macchina prestazionale**: la prestazione si trasforma in ottimizzazione biologica del soggetto.
- **Stanchezza che divide**: la stanchezza da esaurimento distrugge parola, sguardo, comunità.
- **Stanchezza fondamentale del noi**: apre un "tra", rende permeabile l'io al mondo.
- **Non-fare come sabato**: la stanchezza profonda è tempo sacro del gioco, non semplice pausa.
- **Comunità dei singolari**: la società futura è quella dello stanco in senso peculiare, ritmata e cortese.

#### Parole chiave
stanchezza, Handke, non-fare, sabato, comunità, potenza negativa, doping, in-differenza, cortesia

---

### Appendice — La società del burnout

L'apparato psichico di Freud presuppone una società repressiva: rimozione, censura, Super-io. Il soggetto tardo-moderno, invece, è un soggetto affermativo, dominato dal potere e non dal dovere: la psicoanalisi non riesce più a descriverlo. Han rilegge Ehrenberg, Sennett, Agamben per mostrare come la depressione e il burnout non nascano dalla negazione ma dall'incapacità di dire no, dall'autoriferimento narcisistico privo di alterità, dalla concorrenza con se stessi. Il narcisismo non produce amor proprio ma dolore del sé: nel virtuale, senza principio di realtà, il soggetto incontra sempre e solo se stesso. Manca l'Altro come istanza della gratificazione: il soggetto non giunge mai a un traguardo, si consuma in una ruota da criceto, si sfrutta fino al burnout. Il Super-io repressivo viene rimpiazzato dall'Io-ideale seduttivo: non più sottomissione ma progetto, non più costrizione esterna ma autocostrizione. La distanza incolmabile tra Io reale e Io-ideale genera autoaggressività, che può radicalizzarsi nel suicidio. Autorealizzazione e autodistruzione coincidono. Han corregge anche la tesi agambeniana: siamo tutti *homines sacri*, ma il bando che ci rende tali non è più quello sovrano, è il bando della prestazione. La vita si riduce a nuda sopravvivenza da mantenere in salute: gli *homines sacri* della prestazione non sono uccidibili, sono zombie della salute, "troppo vivi per morire e troppo morti per vivere". L'economia neoliberale sfrutta perché maschera lo sfruttamento da libertà: da qui l'assenza di rivolta.

#### Concetti chiave
- **Freud non basta più**: l'inconscio della rimozione era il prodotto della società disciplinare.
- **Narcisismo e crisi della gratificazione**: senza Altro il soggetto non arriva mai al riconoscimento.
- **Dal Super-io all'Io-ideale**: sottomissione sostituita da progetto e autocostrizione.
- **Autosfruttamento neoliberale**: la libertà è la forma più efficiente dello sfruttamento.
- **Homo sacer della prestazione**: siamo morti viventi conservati come merce da valorizzare.

#### Parole chiave
burnout, Freud, narcisismo, Io-ideale, autosfruttamento, neoliberalismo, homo sacer, gratificazione, depressione

---

### Tempo solenne

Viviamo in un tempo senza festa. La festa (dal latino *feriae*, *festus*) è tempo sacro, sospeso, intramontabile: la si "celebra" come si percorre uno spazio, non come si consuma un intervallo. Han, con Gadamer e Kerényi, ricorda che l'essenza dell'esperienza estetica è imparare a indugiare — controparte finita dell'eternità. La festa dischiudeva l'accesso al divino: nel gioco e nel rito ci si faceva simili agli dèi. Oggi festival ed eventi sono l'opposto della festa: l'*eventus* è l'imprevisto, casuale, non vincolante. Il tempo di lavoro è divenuto totale e ha divorato ogni tempo solenne; anche la pausa è tempo di lavoro, funzionale al riprendere. Nell'ipercapitalismo lo sfruttamento non appare più come alienazione ma come autorealizzazione, e il primo sintomo del burnout è l'euforia. Perfino la libertà del *potere* produce più costrizione del *dovere* disciplinare, perché è priva di limiti. La vita si è irrigidita in sopravvivenza, l'isteria della salute e del fitness la trasforma in un morto vivente: Adorno lo dice chiaramente, senza malattia il sano diventa già malattia. Han evoca l'aristotelica *bios politikos* come vita libera perché libera dalla necessità, e denuncia la degradazione dei politici a manovali del sistema. Attraverso Agamben propone la *profanazione* come restituzione delle cose al gioco: come i bambini greci che, nella crisi, hanno strappato banconote giocandoci, così dobbiamo profanare capitale, lavoro, tempo, e trasformarli in gioco e festa. Il mondo è diventato un grande magazzino, dove tutto ha lifetime value e ogni relazione è commercio; ci manca l'essenziale, ossia il mondo. La proposta è riconvertire il *Warenhaus* in *Festhaus*, casa festiva in cui valga la pena vivere.

#### Concetti chiave
- **Festa vs. evento**: la festa è tempo intramontabile, l'evento è casualità della società odierna.
- **Assolutizzazione del lavoro**: la scomparsa del tempo solenne è divorata dal tempo di lavoro totale.
- **Libertà del potere come costrizione illimitata**: la libertà senza divieto genera più costrizione della disciplina.
- **Profanazione come gioco**: restituire le cose al gioco è la via per liberarsi dal culto del capitale.
- **Dal grande magazzino alla casa festiva**: l'ipercapitalismo va ricondotto a uno spazio abitabile e sacro.

#### Parole chiave
festa, tempo solenne, profanazione, gioco, lavoro, capitale, sopravvivenza, ipercapitalismo, bellezza, politica

---

### Sintesi generale del libro

*La società della stanchezza* è una diagnosi filosofica del disagio contemporaneo. La tesi centrale è che siamo passati dalla società disciplinare, descritta da Foucault e fondata sulla negatività del divieto, a una società della prestazione fondata sulla positività del "poter-fare". Questo cambiamento non è liberazione ma continuità: l'imperativo esterno è stato interiorizzato come autoimperativo, il soggetto è divenuto imprenditore di se stesso e sfrutta se stesso con più efficienza di quanto qualsiasi padrone potrebbe. La libertà si rovescia in costrizione, perché — a differenza del dovere, che ha limiti — il potere è aperto verso l'alto e non finisce mai. La coincidenza di libertà e sfruttamento produce autoaggressività: il soggetto fa guerra a se stesso, e le patologie tipiche del XXI secolo — depressione, ADHD, borderline, burnout — sono infarti di questa guerra intestina, non malattie da agenti estranei ma esiti di un eccesso di positività, di stimoli, di prestazione, di Eguale.

I capitoli sono legati da questa idea guida. *La violenza neuronale* mostra che le nuove patologie si sottraggono allo schema immunologico perché nascono dall'immanenza del sistema. *Oltre la società disciplinare* traccia il passaggio storico dal soggetto d'obbedienza al soggetto di prestazione. *La noia profonda* e *La pedagogia del vedere* mostrano il volto attentivo del problema: iperattenzione e iperattività distruggono contemplazione, potenza negativa, capacità di dire no. *Vita activa* critica Arendt e mostra la nuda vita ridotta a sopravvivenza. *Il caso Bartleby* smonta la lettura onto-teologica di Agamben e ricolloca il racconto nella patologia della disciplina. *La società della stanchezza* propone, con Handke, la contrapposizione fondamentale tra stanchezza dell'esaurimento e stanchezza del "noi", ispiratrice, cortese, capace di ridischiudere il mondo. L'appendice *La società del burnout* radicalizza la diagnosi, mostrando come il Super-io repressivo sia stato sostituito dall'Io-ideale seduttivo e come autorealizzazione e autodistruzione coincidano. *Tempo solenne* chiude con una prospettiva positiva: la profanazione del lavoro, del capitale, del tempo, e la restituzione al gioco, alla festa, alla contemplazione, come vie per uscire dalla nuda sopravvivenza.

Le conclusioni dell'autore sono duplici. Da una parte una critica radicale al neoliberalismo, che rende invisibile lo sfruttamento perché lo maschera da libertà, e all'ipercapitalismo che converte ogni relazione in valore di mercato. Dall'altra un'indicazione terapeutica: recuperare la potenza negativa del non-fare, la stanchezza che cura, il tempo solenne della festa, l'attenzione contemplativa. Non decelerazione né accelerazione, ma un tempo altro. Solo una nuova narrazione — capace di reintrodurre alterità, indugio, forma e bellezza — può salvarci dal diventare zombie iperattivi in un mondo trasformato in grande magazzino.
